def bfs(graph, starting_node):
    visited_nodes = []
    queue = [starting_node]

    while queue:
        node = queue.pop(0)
        if node not in visited_nodes:
            visited_nodes.append(node)
            print(node, end=" ")

            for neighbor in graph[node]:
                if neighbor not in visited_nodes and neighbor not in queue:
                    queue.append(neighbor)

graph = {
    'A': ['B', 'C'],
    'B': ['D', 'E'],
    'C': ['F', 'G'],
    'D': [],
    'E': ['H', 'I'],
    'F': [],
    'G': [],
    'H': [],
    'I': ['J', 'K'],
    'J': [],
    'K': ['L'],
    'L': []
}

print("This is the Breadth-First Search (BFS) : ")
bfs(graph, 'A')
