class Graph:
    def __init__(self, num_nodes):
        self.graph = {}
        self.num_nodes = num_nodes
        for i in range(num_nodes):
            self.graph[i] = []

    def add_edge(self, source, destination):
        self.graph[source].append(destination)

    def topological_sort_util(self, node, visited, stack):
        visited[node] = True
        for neighbor in self.graph[node]:
            if not visited[neighbor]:
                self.topological_sort_util(neighbor, visited, stack)
        stack.insert(0, node)

    def topological_sort(self):
        visited = [False] * self.num_nodes
        stack = []

        for node in range(self.num_nodes):
            if not visited[node]:
                self.topological_sort_util(node, visited, stack)

        return stack

graph = Graph(5)
graph.add_edge(0, 1)
graph.add_edge(0, 3)
graph.add_edge(1, 2)
graph.add_edge(2, 3)
graph.add_edge(2, 4)
graph.add_edge(3, 4)

print("This is the Topological Sort of the graph:")
print(graph.topological_sort())